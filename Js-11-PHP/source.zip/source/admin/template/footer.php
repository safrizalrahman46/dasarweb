<!-- Bootstrap JavaScript -->
<script src="assets/dist/js/bootstrap.bundle.min.js"></script>

<!-- Chart.js for data visualization -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.3.2/dist/chart.umd.js"
    integrity="sha384-eI7PSr3L1xLlSH3JdDIl5YN/njoSxfbxrCInJrzXt+ENPSMOVBXbD+Lb6sEG4zopL"
    crossorigin="anonymous"></script>

<!-- Custom Dashboard JavaScript -->
<script src="assets/custom/dashboard.js"></script>
</body>

</html>